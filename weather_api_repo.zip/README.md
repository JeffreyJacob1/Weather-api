# Weather API Repository
This is a sample Django-based weather API repository.